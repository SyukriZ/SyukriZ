<div align="center">

<img src="assets/header.svg" alt="Syukri Zainal — Computer Science student and founder of 7NVENT" width="100%">

<br>

[![LinkedIn](https://img.shields.io/badge/LinkedIn-111111?style=flat-square&logo=linkedin&logoColor=white&labelColor=111111)](https://linkedin.com/in/YOUR_LINKEDIN)
[![Email](https://img.shields.io/badge/Email-111111?style=flat-square&logo=gmail&logoColor=white&labelColor=111111)](mailto:YOUR_EMAIL)
[![GitHub](https://img.shields.io/badge/GitHub-111111?style=flat-square&logo=github&logoColor=white&labelColor=111111)](https://github.com/YOUR_USERNAME)

</div>

<br>

<img src="assets/about.svg" alt="About Syukri" width="100%">

<br>

<img src="assets/stack.svg" alt="Tech stack" width="100%">

<br>

<a href="https://github.com/YOUR_USERNAME/YOUR_7NVENT_REPO">
  <img src="assets/project.svg" alt="7NVENT — bill payment and hotel inventory management" width="100%">
</a>

<br>

<div align="center">

<img src="https://github-readme-stats.vercel.app/api?username=YOUR_USERNAME&show_icons=true&hide_border=true&bg_color=00000000&title_color=ffffff&text_color=9ca3af&icon_color=ffffff&ring_color=ffffff" height="165" alt="GitHub stats">
<img src="https://github-readme-stats.vercel.app/api/top-langs/?username=YOUR_USERNAME&layout=compact&hide_border=true&bg_color=00000000&title_color=ffffff&text_color=9ca3af" height="165" alt="Top languages">

</div>

<br>

<img src="assets/footer.svg" alt="Open to internships and collaboration" width="100%">
